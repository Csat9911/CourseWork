#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <dirent.h>
#include <string.h>

#define BUFSIZE 100
/*
Created by Colton Carls and Varun Shah
Due Date: 3/12/21
Description:
Word Wrapping Program that reads from a file and outputs to stdout or another file
Can only use low level IO, read() open() close() write().
*/
int nameStart(char *pre, char *prefix){
   if(strncmp(pre, prefix, strlen(prefix)) == 0){
      return 1;
   }
   else{
      return 0;
   }
}
int nameEnd(char *pre, char *suffix){
  int prelen = strlen(pre);
  int suffixlen = strlen(suffix);
  return (0 == strcmp(pre + (prelen-suffixlen), suffix));
}
int main(int argc, char *argv[]) {
  if(argc != 2 && argc != 3){
    perror("Too few or to many arguments");
    return EXIT_FAILURE;
  }
  int width = atoi(argv[1]);
  if(width <= 0){
    perror("Width is to small");
    return EXIT_FAILURE;
  }
  char buffer[BUFSIZE];
  char stash[BUFSIZE];
  memset(buffer,0,BUFSIZE);
  int bytes_read;
  int counter=0;
  int stashIndex=0;
  int status = 0;
  //Case 1: A file is not given: Read from Stdin; *crtl-D escapes stdin*
  if (argc == 2){
    while((bytes_read = read(0,&buffer,BUFSIZE))!=0){
      for(int i=0;i<bytes_read;i++){
        if(buffer[i]=='\n' && stashIndex < 3){
            write(1,"\n",1);
        }
         //problem with isspace() here 
        if(buffer[i] != ' ' && buffer[i] != '\n' && buffer[i] != '\t' && buffer[i] != '\v' && buffer[i] != '\r' && buffer[i] != '\v'){
          //not a space
          stash[stashIndex] = buffer[i];
          stashIndex++;
        }
        else{
          //this is a space
          if((counter+stashIndex+1)<=width){
            for(int j=0;j<stashIndex+1;j++){
              write(1,&stash[j],1);
              counter++;
            }
            if((stashIndex+1+counter) != width-1){
              write(1," ",1);
            }
          }
          else{
            if(counter!=0){
              write(1,"\n",1);
            }
            if(counter-1>width){
              status=1;
            }
            counter=0;
            for(int j=0;j<stashIndex+1;j++){
              write(1,&stash[j],1);
              counter++;
            }
            write(1," ",1);
          }
          stashIndex=0;
          memset(stash,0,BUFSIZE);
        }
      }
    }
    //anything last stash
     if((counter+stashIndex+1)<=width){
        for(int j=0;j<stashIndex+1;j++){
          write(1,&stash[j],1);
            }
     }
      else{
        write(1,"\n",1);
        for(int j=0;j<stashIndex+1;j++){
          write(1,&stash[j],1);
            }
      }
      write(1,"\n",1);
  if(status==0){
    return EXIT_SUCCESS;
  }
  else{
    return EXIT_FAILURE;
  }
   }
  //Case 2: A file is correct: Read from file 
  if(argc == 3){
    struct stat name;
    stat(argv[2],&name);
    if(S_ISDIR(name.st_mode)){
      //directory
      DIR* dr;
      struct dirent *readir;
      struct stat statbuf;
      char *dir = argv[2];
      dr = opendir(dir);
      if (!dr){
      	perror(dir);
        return EXIT_FAILURE;
      }
      while((readir=readdir(dr)) != NULL){
      	stat(readir->d_name,&statbuf);
        int n= nameStart(readir->d_name, "wrap.");
        int m= nameStart(readir->d_name, ".");
        int o= nameEnd(readir->d_name, ".txt");
        if(n==1 || m==1 || o==0){
        	continue;
        }
        else{
        	char arr1[100];
            char temp[100];
            strcpy(arr1,dir);
            strcat(arr1,"/");
            char arr[100];
            strcpy(arr,dir);
            strcat(arr,"/");
            strcat(arr, readir->d_name);
            strcpy(temp,readir->d_name);
            char wrapper[]="wrap.";
            strcpy(readir->d_name,wrapper);
            strcat(readir->d_name,temp);
            strcat(arr1,readir->d_name);
            int fd = open(arr1, O_WRONLY | O_TRUNC | O_CREAT, 0700);
            if (fd < 0){
            	perror("open failed");
                return EXIT_FAILURE;
            }
            int file = open(arr,O_RDONLY,S_IRWXU);
            if (file < 0){
            	perror("open failed");
                return EXIT_FAILURE;
            }
            while((bytes_read = read(file,&buffer,BUFSIZE))!=0){
            	for(int i=0;i<bytes_read;i++){
            		if(buffer[i]=='\n' && stashIndex < 3){
            			write(fd,"\n",1);
                    }
         //problem with isspace() here 
        if(buffer[i] != ' ' && buffer[i] != '\n' && buffer[i] != '\t' && buffer[i] != '\v' && buffer[i] != '\r' && buffer[i] != '\v'){
          //not a space
          stash[stashIndex] = buffer[i];
          stashIndex++;
        }
        else{
          //this is a space
          if((counter+stashIndex+1)<=width){
            for(int j=0;j<stashIndex+1;j++){
              write(fd,&stash[j],1);
              counter++;
            }
            if((stashIndex+1+counter) != width-1){
              write(fd," ",1);
            }
          }
          else{
            if(counter!=0){
              write(fd,"\n",1);
            }
            if(counter-1>width){
              status=1;
            }
            counter=0;
            for(int j=0;j<stashIndex+1;j++){
              write(fd,&stash[j],1);
              counter++;
            }
            write(fd," ",1);
          }
          stashIndex=0;
          memset(stash,0,BUFSIZE);
        }
      }
    }
    //anything last stash
     if((counter+stashIndex+1)<=width){
        for(int j=0;j<stashIndex+1;j++){
          write(fd,&stash[j],1);
            }
     }
      else{
        write(fd,"\n",1);
        for(int j=0;j<stashIndex+1;j++){
          write(fd,&stash[j],1);
            }
      }
    close(file);
                }
        }
        closedir(dr);
        if(status==0){
    return EXIT_SUCCESS;
  		}
  		else{
  			return EXIT_FAILURE;
  		}
    }
    else if(S_ISREG(name.st_mode)){
      //file
      int file = open(argv[2],O_RDONLY,S_IRWXU);
      if (file < 0) {
        perror("open failed");
        return EXIT_FAILURE;
      }
      while((bytes_read = read(file,&buffer,BUFSIZE))!=0){
       for(int i=0;i<bytes_read;i++){
         if(buffer[i]=='\n' && stashIndex < 3){
          write(1,"\n",1);
         }
         //problem with isspace() here 
        if(buffer[i] != ' ' && buffer[i] != '\n' && buffer[i] != '\t' && buffer[i] != '\v' && buffer[i] != '\r' && buffer[i] != '\v'){
          //not a space
          stash[stashIndex] = buffer[i];
          stashIndex++;
        }
        else{
          //this is a space
          if((counter+stashIndex+1)<=width){
            for(int j=0;j<stashIndex+1;j++){
              write(1,&stash[j],1);
              counter++;
            }
            if((stashIndex+1+counter) != width-1){
              write(1," ",1);
            }
          }
          else{
            if(counter!=0){
              write(1,"\n",1);
            }
            if(counter-1>width){
              status=1;
            }
            counter=0;
            for(int j=0;j<stashIndex+1;j++){
              write(1,&stash[j],1);
              counter++;
            }
            write(1," ",1);
          }
          stashIndex=0;
          memset(stash,0,BUFSIZE);
        }
      }
    }
    //anything last stash
    if((counter+stashIndex+1)<=width){
    	for(int j=0;j<stashIndex+1;j++){
        write(1,&stash[j],1);
        }
    }
    else{
    	write(1,"\n",1);
        for(int j=0;j<stashIndex+1;j++){
        write(1,&stash[j],1);
        }
    }
    if(status==0){
    	return EXIT_SUCCESS;
  	}
  	else{
  		return EXIT_FAILURE;
  	}
    close(file);
    }
  }
}
//End Program
