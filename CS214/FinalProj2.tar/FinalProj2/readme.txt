Colton Carls - cwc74
Varun Shah - vrs59

Date: April 20th 2021

Program Name-
Word Frequency Distribution

Program Description -
This program anaylzes multiple files and compares there content to see if the text in the files are similar or not. This program
performs this by using multiple threads to make the work faster. There are two phases. A collection phase which gathers all the files
and known directories from the working path and computes the frequency of each word in those files. The analysis phase examines further
and computes the Jensen-Shannon distance. 

Data Structures Used-

-[Queues] are used for the directories and file threads. These queues are not the same however. The directory queue is unbounded and the file
queue is bounded. This prevents the directories thread from sending to many files at once to the file queue. 

-[Linked List(WFD)] the WFD structure holds the name of every file and all the words that file contains. For the WFD we decided to use a 2d linked List.
It is similar to a 2s array but its solely with linked lists. We found this would be the best structure to use since it was simple and you could adjust 
certain fields in the struct accordingly if we needed to add something. Below shows a representation of this structure.
The (F) in the structure represent a file name, the W represents a word from that file stored underneath its apporiate file name.

F(1) -> F(2) -> F(3) -> F(4)
  |       |      |       |
  W(1)    W(1)   W(1)    W(1)
  |        |     |        |
  W(2)    W(2)   W(2)     W(2)

-[Linked List] - Lastly we used a simple linked list to store the mean frequency to easily grab and caluclate the KLD and finally the JSD

Testing Strategy-
Our testing strategy had a lot of manual testing. We tested to see if optional arguments came before  the regular arguments and if they occurred more than once. We tested many different types of files to make sure the optional arguments worked properly. We tested multiple files in a directory to see if the distance would print correctly. We also made several sub-directories to see that they would get properly accounted for. 