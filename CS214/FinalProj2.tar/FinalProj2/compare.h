#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>

#define FileQSize 20
//File Containing Functions Used in Compare.c so code doesnt get overcrowded

//STRUCTS
//*******************************************************

typedef struct compRes {
    char *file1,*file2;
    double tokens;
    double distance;
} compRes;

typedef struct QNode {
    char *path;
    struct QNode *next;
} QNode;

typedef struct meanFreqList {
    double meanFreq;
    struct meanFreqList *next;
} meanFreqList;

typedef struct Filequeue {
    //Should be an unbounded Queue
    int count;
    QNode *front; 
    QNode *rear;
    int open;
    pthread_mutex_t lock;
    pthread_cond_t read_ready;
    pthread_cond_t write_ready;
}Filequeue;

typedef struct Dirqueue {
    //Should be an unbounded Queue
    int count;
    QNode *front; 
    QNode *rear;
    int open;
    pthread_mutex_t lock;
    pthread_cond_t read_ready;
    pthread_cond_t write_ready;

}Dirqueue;

typedef struct WordList {
    char name[1000];
    double count;
    double freq;
    struct WordList *next;
} WordList;

typedef struct WFD {
    char name[1000];
    WordList *list;
    double wordCount;
    struct WFD *next;
} WFD;

typedef struct targs {
    Filequeue *FQ;
    Dirqueue *DQ;
    WFD *WD;
    compRes *cR;
    int numFiles;
    int comparisons;
    int id;
    int max;
    int wait;
} targs;


//STRUCT FUNCTIONS
//*******************************************************
char * DirDequeue(Dirqueue *Q);
int FileEnqueue(Filequeue *Q, char* path);
int DirEnqueue(Dirqueue *Q, char* path);
int nameStart(char *pre, char *prefix);
int checkFileorDir(char* name);
void directorySearch(void *A, char *ret);
char *FileDequeue(Filequeue *Q);
WFD *FileWFD(WFD *WD, char *FileName);
void freqCalc(WFD *WD);
void dumpDetails (WFD *currChild);
void addWFDNODE (WFD **first, char *name);
double file_tokens(WFD *WD,int fileNum);
 int computeMean(WFD *WD,int f1, int f2, meanFreqList **head);
void addMeanFreq (meanFreqList **first, double res);
int sort_comp(const void * a,const void * b);

void queue_init(Filequeue *Q)
{   
    //initialize the File queue
    Q->front = NULL;
    Q->rear = NULL;
    Q->count = 0;
    Q->open = 1;
    pthread_mutex_init(&Q->lock,NULL);
}
void dqueue_init(Dirqueue *Q)
{
    //initialize the Directorry Queue
    Q->front = NULL;
    Q->rear = NULL;
    Q->count = 0;
    Q->open = 1;
    pthread_mutex_init(&Q->lock,NULL);
}
char *file_name(WFD *WD,int fileNum){
    //functions retrieves the name of the file
    WFD *cur = WD;
    int i =0;
    while(i<fileNum){
        i++;
        cur = cur->next;
    }
    char *temp = malloc(strlen(cur->name)+1);
    strcpy(temp,cur->name);
    return temp;
}

double file_tokens(WFD *WD,int fileNum){
    //gets the current files wordcount
    WFD *cur = WD;
    int i =0;
    while(i<fileNum){
        i++;
        cur = cur->next;
    }
    double total;
    total = cur->wordCount;
    return total;
}
 int computeMean(WFD *WD,int f1, int f2, meanFreqList **head){
    //f1 and f2 help find the file
    //first find the file and its list
    WFD *file1 = WD;
    WFD *file2 = WD;

    int i=0;
    int y =0;
    while(i<f1){
        //find file 1
        i++;
        file1 = file1->next;
    }
    while(y<f2){
        //find file 2
        y++;
        file2 = file2->next;
    }
    WordList *fil1 = file1->list;
    WordList *fil2 = file2->list;
   while(fil1 != NULL && fil2 !=NULL){
          if(strcmp(fil1->name,fil2->name) == 0){
              double result = 0.5*(fil1->freq + fil2->freq);
              addMeanFreq(head,result);
              fil1 = fil1->next;
              fil2 = fil2->next;
          }
            else if(strcmp(fil1->name,fil2->name) > 0){
                double result = 0.5*(fil2->freq);
                addMeanFreq(head,result);
                fil2 = fil2->next;
            }
            else if(strcmp(fil1->name,fil2->name)<0){
                //first word comes first in alphabet, second one does not appear
                //only calculate the mean freq for the first word
                double result = 0.5*(fil1->freq);
               addMeanFreq(head,result);
                fil1 = fil1->next;

            }

    }
    return 1;
    //now both files have been found in WFD
    //grab frequency 

}
double computeJSD(void *A, int f1, int f2){
    //first compute the mean frequencies for each word found in both files
    //f(x) = 0.5(f1(x) + f2(x))       mean frequency is both frequency of the same word added up and multipled by 1/2
   struct targs *args = A;
    meanFreqList *head = NULL;
    computeMean(args->WD,f1,f2,&head);

    WFD *file1 = args->WD;
    WFD *file2 = args->WD;

    double file1Sum=0.0;
    double file2Sum=0.0;
    int i=0;
    int y =0;
    while(i<f1){
        //find file 1
        i++;
        file1 = file1->next;
    }
    // calculate KLD
    WordList *fil1 = file1->list;
    meanFreqList *temp = head;
    while(fil1 != NULL){
        file1Sum += fil1->freq * log2(fil1->freq/temp->meanFreq) ;
        temp = temp->next;
        fil1 = fil1->next;
    }

    WordList *fil2 = file2->list;
    meanFreqList *temp1 = head;
    while(y<f2){
        //find file 2
        y++;
        file2 = file2->next;
    }
    while(fil2 != NULL){
        file2Sum += fil2->freq * log2(fil2->freq/temp1->meanFreq) ;
        temp1 = temp1->next;
        fil2 = fil2->next;
    }

    double JSD = sqrt((0.5*file1Sum)+(0.5*file2Sum));
    return JSD;
}
void *JSDcompFunc(void *A){
    int i=0;
    int f1,f2;
    struct targs *args = A;
    for(f1=0;f1<args->numFiles;f1++){
        for(f2 = f1+1;f2<args->numFiles;f2++){
            args->cR[i].file1 = file_name(args->WD,f1);
            args->cR[i].file2 = file_name(args->WD,f2);
            args->cR[i].tokens = file_tokens(args->WD,f1) + file_tokens(args->WD,f2);
            args->cR[i].distance = computeJSD(args,f1,f2);
            i++;
        }

    }
    qsort(args->cR,args->comparisons,sizeof(compRes),sort_comp);
    for(int x=0;x<args->comparisons;x++){
        printf("%f %s %s\n",args->cR[x].distance,args->cR[x].file1,args->cR[x].file2);
    }
    return NULL;
}

int sort_comp(const void * a,const void * b){
    if(*(double*)a > *(double*)b){
        return 1;
    }
    else if(*(double*)a < *(double*)b){
        return -1;
    }
    else{
        return 0;
    }
}

//DIRECTORY Q insert and delete
//STILL TRYING TO FIGURE OUT THE DIRECTORY Q CODE
void *DirFunc(void *A){
    struct targs *args = A;
    //args->Q
    //could run and say while the q is not empty
    while(args->DQ->count != 0){
        char *ret = DirDequeue(args->DQ);
        directorySearch(args,ret);
        free(ret);
   }
   return NULL;
}
WFD *FileFunc(void *A, WFD *WD){
    struct targs *args = A;
    while(args->FQ->count != 0){
        char *ret;
        ret = FileDequeue(args->FQ);
        addWFDNODE(&WD,ret);
        args->WD = FileWFD(WD,ret);
    }
    return WD;
}


int DirEnqueue(Dirqueue *Q, char* path){
    if(Q->count < FileQSize){
        QNode *temp = malloc(sizeof(QNode));
        temp->path = path;
        temp->next = NULL;
        if(Q->rear != NULL){
            Q->rear->next = temp;
            Q->rear = temp;
        }
        else{
            Q->front = Q->rear = temp;
        }
        Q->count++;
    }
    return 0;
}

char *DirDequeue(Dirqueue *Q){
    QNode *temp = Q->front;
    char *ret = malloc(strlen(temp->path)+1);
    if(Q->front == NULL){
        //cant pop from empty q
        return NULL;
    }
    Q->front = Q->front->next;
    if(Q->front == NULL){
        Q->rear = NULL;
    }
    Q->count--;
    strncpy(ret,temp->path,strlen(temp->path)+1);
    free(temp);
    return ret;
}

//FILE QUEUE INSERT AND DELETE
int FileEnqueue(Filequeue *Q, char* path){
    pthread_mutex_lock(&Q->lock);
    
    while (Q->count == FileQSize && Q->open) {
        pthread_cond_wait(&Q->write_ready, &Q->lock);
    }
    if (!Q->open) {
        pthread_mutex_unlock(&Q->lock);
        return -1;
    }
    if(Q->count < FileQSize){
        QNode *temp = malloc(sizeof(QNode));
        temp->path = malloc(strlen(path)+1);
        strcpy(temp->path,path);
        //temp->path = path;
        //strcpy (temp->path, path);
        temp->next = NULL;
        if(Q->rear != NULL){
            Q->rear->next = temp;
            Q->rear = temp;
        }
        else{
            Q->front = Q->rear = temp;
        }
        Q->count++;
    }

    //pthread_cond_signal(&Q->read_ready);
    
    pthread_mutex_unlock(&Q->lock);
    
    return 0;
    
}

char *FileDequeue(Filequeue *Q){
    QNode *temp = Q->front;
    char *ret = malloc(strlen(temp->path)+1);
    memset(ret,'\0',strlen(temp->path)+1);
    pthread_mutex_lock(&Q->lock);
    
    while (Q->count == 0 && Q->open) {
        pthread_cond_wait(&Q->read_ready, &Q->lock);
    }
    if (Q->count == 0) {
        pthread_mutex_unlock(&Q->lock);
    }
    if(Q->front == NULL){
        //cant pop from empty q
    }
    Q->front = Q->front->next;
    if(Q->front == NULL){
        Q->rear = NULL;
    }
    Q->count--;
    ret = temp->path;
    //strcpy(ret,temp->path);
    free(temp);
    //pthread_cond_signal(&Q->write_ready);
    
    pthread_mutex_unlock(&Q->lock);
    return ret;
}

void Qdisplay(QNode *head){
    if(head == NULL){
        return;
    }
    else{
        printf("Q currently Holds: [%s]\n",head->path);
        Qdisplay(head->next);
    }
}

//REGULAR FUNCTIONS
//*********************************************************
int checkFileorDir(char* name){
    //simple function to check if path given is a file or not. If not return 0
    struct stat s;
    if(stat(name,&s)==0){
        if(S_ISDIR(s.st_mode)){
        //given thing is a directory
        return 0;
        }
        if(S_ISREG(s.st_mode)){
        //given thing is a file
        return 1;
        }
    }
    return -1;
}
int nameStart(char *pre, char *prefix){
   if(strncmp(pre, prefix, strlen(prefix)) == 0){
      return 1;
   }
   else{
      return 0;
   }
}

void directorySearch(void *A,char *ret){
    struct targs *args = A;
    char path[2000];
    struct dirent *dp;
    DIR *dir = opendir(ret);
    strncpy(path,ret,strlen(ret));
    if(!dir){
    return;
    }
    while((dp=readdir(dir))!=NULL){
        if(dir && path[strlen(path)-1] != '/'){
            strcat(path,"/");
        }
        int m = nameStart(dp->d_name, ".");
        int checkNum;
        if(m==1){
            continue;
        }
        else{
            strcpy(path,ret);
            strcat(path,"/");
            strcat(path, dp->d_name);
            checkNum = checkFileorDir(path);
            if(checkNum == 0){
                //dir
                DirEnqueue(args->DQ,path);
            }
            else if(checkNum == 1){
                //file
                args->numFiles++;
                FileEnqueue(args->FQ,path);
                 
            }
        }
    }
    closedir(dir);
}

void addMeanFreq (meanFreqList **first, double res) {
   meanFreqList *newest = malloc(sizeof(meanFreqList));
    newest->meanFreq = res;
    newest->next = *first;
    *first = newest;
}


void addWFDNODE (WFD **first, char *name) {
    WFD *newest = malloc(sizeof(WFD));
    strcpy (newest->name, name);
    newest->next = *first;
    *first = newest;
}

void addWordlist (WFD *first, char *name) {
    WordList *newest = malloc(sizeof(WordList));
    WordList *cur = first->list;
    WordList *prev = NULL;

    strcpy (newest->name, name);

    while(cur !=NULL && strcmp(newest->name,cur->name)>=0){
        if(strcmp(newest->name,cur->name) == 0){
            cur->count++;
        return;
    }
        prev = cur;
        cur = cur->next;
    }
    if(NULL == prev){
        newest->count++;
        newest->next = cur;
        first->list = newest;
    }
    else{
        newest->count++;
        prev->next = newest;
        newest->next = cur;
    }
}

WFD *FileWFD(WFD *WD, char *FileName){
    //int space = 1;
    int i,j;
    //int x=0;
    //int line = 0;
    //char c;
    char words[1000];
    int punc;
    FILE * fp=fopen(FileName,"r");
     if(!fp){
        perror("Error: ");
        return NULL;
    }
    while(fscanf(fp, "%s", words)!=EOF){
        //make all words lowercase
        for(i=0;i<=strlen(words);i++){
           words[i]=tolower(words[i]); 
        }
        //remove punctuation
        for(i=0;i<=strlen(words);i++){
            punc = ispunct(words[i]);
            if(punc != 0){
                for (j=i; j<strlen(words); j++){
            words[j]=words[j+1];
        }
            }
        }
        WD->wordCount++;
        addWordlist(WD,words);
    }
    fclose(fp);
    freqCalc(WD);
    return WD;
}

void freqCalc (WFD *WD) {
    // For every child.
    WFD *cur = WD;
    while (cur!= NULL) {
        // For every toy that child has.
        WordList *Wcur = cur->list;
        if (Wcur == NULL) {
            continue;
        } else {
            while (Wcur != NULL) {
                Wcur->freq = Wcur->count/cur->wordCount;
                Wcur= Wcur->next;
            }
        }
        break;
    }
}
