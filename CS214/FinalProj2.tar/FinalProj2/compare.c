#include "compare.h"
/*
Colton Carls 
Word Frequency Distribution- This program anaylzes multiple files and compares there content to see if the text in the files are similar or not. This program
performs this by using multiple threads to make the work faster. 
THINGS TO NOTE ABOUT THE PROGRAM-
* Arguments given are relative to the working directory (This is in the instructions)
* We require that Optional Arguments come before Regular Arguments (Specific to our program)
* Optional Arguments should only occur once, if they occur more than once they will be ignored (Specific to our program)
*/

int dirThread = 1;
int fileThread = 1;
int analThread = 1;
char DIRECTORYS[100] = "1";
char FILES[100] = "1";
char ANALYSISS[100] = "1";
char SUFFIX[100] = ".txt";

pthread_mutex_t lock;

struct arg_holder {
    int argc;
    char ** argv;
};

void *directory_thread(void *arg){
    pthread_mutex_lock(&lock);
    struct arg_holder *args = arg;
    targs *argss;
    //pthread_t *dirT;
    //pthread_t *fileT;
    Filequeue *FQ;
    Dirqueue *DQ;
    WFD *WD = NULL;
    FQ = malloc(sizeof(Filequeue));
    queue_init(FQ);
    DQ = malloc(sizeof(Dirqueue));
    dqueue_init(DQ);
    argss = malloc(sizeof(struct targs));
    argss->DQ = DQ;
    argss->FQ = FQ;
    //argument is a completed path
    int checkFileNum;
    checkFileNum = checkFileorDir(args -> argv[args -> argc]);
    if(checkFileNum == 0){
        //dir
        DirEnqueue(DQ,args -> argv[args -> argc]);
    }
    else{
        //decide whether its a file or not with given suffix
        char path[200] = "";
        strcat(path,args -> argv[args -> argc]);
        strcat(path,SUFFIX);
        checkFileNum = checkFileorDir(path);
        if(checkFileNum == 1){
            //valid file
            //probably is going to be args.q or something
            FileEnqueue(FQ,path);
        }
        else{
            printf("A directory or File could not be found with that name...\n");
        }

    }
        //Qdisplay(args->DQ->front);
    DirFunc(argss);
    
    //Qdisplay(args->FQ->front);
   WD = FileFunc(argss,WD);
    argss->WD = WD;
    
//analysis phase
    unsigned fileNum = argss->numFiles;
    unsigned comparisons = fileNum * (fileNum-1)/2;
    argss->comparisons = comparisons;
    compRes *results = malloc(comparisons *sizeof(compRes));
    argss->cR = results;
   
    JSDcompFunc(argss);
    pthread_mutex_unlock(&lock);
    return NULL;
}

void *file_thread(void *arg){
    pthread_mutex_lock(&lock);
    struct arg_holder *args = arg;
    targs *argss;
    //pthread_t *dirT;
    //pthread_t *fileT;
    Filequeue *FQ;
    Dirqueue *DQ;
    WFD *WD = NULL;
    FQ = malloc(sizeof(Filequeue));
    queue_init(FQ);
    DQ = malloc(sizeof(Dirqueue));
    dqueue_init(DQ);
    argss = malloc(sizeof(struct targs));
    argss->DQ = DQ;
    argss->FQ = FQ;
    //could be a file, could be a directory we should check
    int checkFileNum;
    checkFileNum = checkFileorDir(args -> argv[args -> argc]);
    if(checkFileNum == 0){
        //Found a directory
        DirEnqueue(DQ,args -> argv[args -> argc]);
    }
    else{
        //decide whether its a file or not with given suffix
        char path[200] = "";
        strcat(path,args -> argv[args -> argc]);
        strcat(path,SUFFIX);
        printf("%s\n",path);
        checkFileNum = checkFileorDir(path);
        if(checkFileNum == 1){
            //valid file
            FileEnqueue(FQ,path);
        }
        else{
            printf("A directory or File could not be found with that name...\n");
        }
    }
        //Qdisplay(args->DQ->front);
    DirFunc(argss);
    
    //Qdisplay(args->FQ->front);
   WD = FileFunc(argss,WD);
    argss->WD = WD;
    
//analysis phase
    unsigned fileNum = argss->numFiles;
    unsigned comparisons = fileNum * (fileNum-1)/2;
    argss->comparisons = comparisons;
    compRes *results = malloc(comparisons *sizeof(compRes));
    argss->cR = results;
   
    JSDcompFunc(argss);
    pthread_mutex_unlock(&lock);
    return NULL;
}

void *analysis_thread(void *arg){
    pthread_mutex_lock(&lock);
    //struct arg_holder *args = arg;
    targs *argss;
    //pthread_t *dirT;
    //pthread_t *fileT;
    Filequeue *FQ;
    Dirqueue *DQ;
    //WFD *WD = NULL;
    FQ = malloc(sizeof(Filequeue));
    queue_init(FQ);
    DQ = malloc(sizeof(Dirqueue));
    dqueue_init(DQ);
    argss = malloc(sizeof(struct targs));
    argss->DQ = DQ;
    argss->FQ = FQ;
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main(int argc, char *argv[]) {
    if(pthread_mutex_init(&lock, NULL) != 0){
        printf("mutex failed\n");
        return -1;
    }
    int checks =0,checka=0, checkf=0, checkd=0, checkafter=0;
    //start with reading arguments given from user and determine if they are directories or files; this will start the enqueue process
    //this handles paths and regular arguments
    // FIX - files or paths given with suffix already
    targs *argsss;
    //pthread_t *dirT;
    //pthread_t *fileT;
    Filequeue *FQ;
    Dirqueue *DQ;
    //WFD *WD = NULL;
    FQ = malloc(sizeof(Filequeue));
    queue_init(FQ);
    DQ = malloc(sizeof(Dirqueue));
    dqueue_init(DQ);
    argsss = malloc(sizeof(struct targs));
    argsss->DQ = DQ;
    argsss->FQ = FQ;
    //read options first and determine what to do with them
    //int totalFDthreads;
    for(int i=1;i<argc;i++){
        if(strstr(argv[i],"-")){
            char command = argv[i][1];
            switch(command){
                case 's':{
                    if(checks==1 || checkafter==1){
                        return -1;
                        break;
                    }
                    strncpy(SUFFIX,&argv[i][2],strlen(argv[i]));
                    checks=1;
                    break;
                }
                case 'a':{
                    //Analysis thread change
                    if(checka==1 || checkafter==1){
                        return -1;
                        break;
                    }
                    strncpy(ANALYSISS,&argv[i][2],strlen(argv[i]));
                    analThread = atoi(ANALYSISS);
                    if(analThread<1){
                        return -1;
                    }
                    checka=1;
                    break;
                }
                case 'f':{
                    //File Thread change
                    if(checkf==1 || checkafter==1){
                        return -1;
                        break;
                    }
                    strncpy(FILES,&argv[i][2],strlen(argv[i]));
                    fileThread = atoi(FILES);
                    if(fileThread<1){
                        return -1;
                    }
                    checkf=1;
                    break;
                }
                case 'd':{
                    //Directory thread change
                    if(checkd==1 || checkafter==1){
                        return -1;
                        break;
                    }
                    strncpy(DIRECTORYS,&argv[i][2],strlen(argv[i]));
                    dirThread = atoi(DIRECTORYS);
                    if(dirThread<1){
                        return -1;
                    }
                    checkd=1;
                    break;
                }
                default: printf("ERROR this is not a valid argument\n");
                break;
            }
            continue;
        }
        else if(strstr(argv[i],"/")){
            checkafter=1;
            struct arg_holder args;
            args.argc = i;
            args.argv = argv;
            int j =0;
            pthread_t *groupd_thread = malloc(sizeof(pthread_t) * dirThread);
            for(j = 0; j < dirThread; ++j){
                pthread_create(&groupd_thread[j], NULL, directory_thread, (void *)&args);
            }
            for(j = 0; j < dirThread; ++j){
                pthread_join(groupd_thread[j], NULL);
            }
        }
        else{
        //could be a file, could be a directory we should check
        checkafter=1;
            struct arg_holder args;
            args.argc = i;
            args.argv = argv;
            int k =0;
            pthread_t *groupf_thread = malloc(sizeof(pthread_t) * fileThread);
            for(k = 0; k < fileThread; ++k){
                pthread_create(&groupf_thread[k], NULL, file_thread, (void *)&args);
            }
            for(k = 0; k < fileThread; ++k){
                pthread_join(groupf_thread[k], NULL);
            }
        }
    }
    int l = 0;
    pthread_t *groupa_thread = malloc(sizeof(pthread_t) * analThread);
    for(l = 0; l < analThread; ++l){
        pthread_create(&groupa_thread[l], NULL, analysis_thread, NULL);
    }
    for(l = 0; l < analThread; ++l){
        pthread_join(groupa_thread[l], NULL);
    }
    return 0;
}
