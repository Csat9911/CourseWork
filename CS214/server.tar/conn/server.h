#define _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <signal.h>
#include <pthread.h>

//Structs
//string buffer used to create strings when using getc
struct connection {
    struct sockaddr_storage addr;
    socklen_t addr_len;
    int fd;
    //asssuming linkedlist head gets passed here
};

typedef struct strbuf_t{
    size_t length;
    size_t used;
    char *data;
} strbuf_t;


typedef struct Linknode{
    //linked list struct
    char *key;
    char *value;
    int charlength;
    struct Linknode *next;
    pthread_mutex_t lock;
} Linknode;

Linknode *LinkHead;

//Functions Declarations
int sb_init(strbuf_t *, size_t);
void sb_destroy(strbuf_t *);
int sb_append(strbuf_t *, char);
int insert(char *key, char *value, int charlength);
char *delete(char *data, int length, FILE* fout);
int init_NodeHead();
void printlist(void);
char *get(char *data, int length, FILE* fout);



//Functions
int sb_init(strbuf_t *L, size_t length){
    L->data = malloc(sizeof(char) * length);
    if (!L->data) return 1;

    L->length = length;
    L->used  = 1;
    L->data[L->used] = '\0';

    return 0;
}

void sb_destroy(strbuf_t *L){
    free(L->data);
}

int sb_append(strbuf_t *L, char item){
    if (L->used == L->length) {

    size_t size = L->length * 2;
    char *p = realloc(L->data, sizeof(char) * size);

	if (!p) return 1;
    
	L->data = p;
	L->length = size;

    }
    L->data[L->used] = '\0';
    L->data[L->used-1] = item;
    ++L->used;

    return 0;
}

char *delete(char *data, int length, FILE* fout){
    if(strlen(data)+1 != length){
        fprintf(fout,"ERR\nLEN\n");
        fflush(fout);
        return NULL;
    }
    Linknode *prev, *curr;
    prev = LinkHead;
    pthread_mutex_lock(&prev->lock);
    while((curr = prev->next) != NULL){
        pthread_mutex_lock(&curr->lock);
        if(strcmp(curr->key,data) == 0){
            //data is equal
            prev->next = curr->next;
            pthread_mutex_unlock(&prev->lock);
            curr->next = NULL;
           pthread_mutex_unlock(&curr->lock);
            return(curr->value);
        }
        pthread_mutex_unlock(&prev->lock);
        prev = curr;
    }
    pthread_mutex_unlock(&prev->lock);
    return NULL;
}

int init_NodeHead(void){
    LinkHead = malloc(sizeof(Linknode));
    if(LinkHead == NULL){
        return -1;
    }
    LinkHead->key = "";
    LinkHead->value = "";
    LinkHead->charlength = 0;
    LinkHead->next = NULL;
    return 0;
}

int insert(char *key, char *value, int charlength){
    //returns a code for error or success
    //basic insert last 
    //check if key and value add up to the char length
    if((strlen(key)+strlen(value)+2) != charlength){
        return -1;
    }
    Linknode *newNode = malloc(sizeof(Linknode));
    if(newNode==NULL){
        return -1;
    }
    newNode->key = malloc(sizeof(strlen(key)+1));
    newNode->value = malloc(sizeof(strlen(value)+1));
    newNode->charlength = charlength;
    Linknode *curr;
    Linknode *prev = LinkHead;
    //copy the value of new node
    strcpy(newNode->key,key);
    strcpy(newNode->value,value);
    newNode->next = NULL;
    pthread_mutex_lock(&prev->lock);
    int existsAlready = 0;
    while((curr = prev->next) != NULL){
        pthread_mutex_lock(&curr->lock);
        if(strcmp(curr->key,key) == 0){
            //current key we are about to add is already present
            existsAlready = 1;
            pthread_mutex_unlock(&prev->lock);
            break;
        }
        pthread_mutex_unlock(&prev->lock);
        prev = curr;
    }
    if(existsAlready == 1){
        //curr has a key already in list
        strcpy(curr->value,value);
        curr->charlength = charlength;
        pthread_mutex_unlock(&curr->lock);
        return 0;
    }
    //after should be at last node in list if it doesnt exist already
    //prev points to null
    prev->next = newNode;
    pthread_mutex_unlock(&prev->lock);
    return 0;
}

void printlist(void){
    Linknode *curr = LinkHead;
     if(curr->next == NULL){
         printf("List contains: NULL");
     }
     else{
        while(curr != NULL){
            printf("List contains: [[%s]]\n",curr->key);
            printf("    ----[[%s]]\n",curr->value);
            printf("    ----[[%d]]\n",curr->charlength);
            curr = curr->next;
    }
     }
   
}

char *get(char *data, int length, FILE* fout){
    if(strlen(data)+1 != length){
        return NULL;
    }
    Linknode *prev, *curr;
    prev = LinkHead;
    pthread_mutex_lock(&prev->lock);
    while((curr = prev->next) != NULL){
        pthread_mutex_lock(&curr->lock);
        if(strcmp(curr->key,data) == 0){
            //data is equal
            pthread_mutex_unlock(&curr->lock);
            pthread_mutex_unlock(&prev->lock);
            return(curr->value);
        }
        pthread_mutex_unlock(&prev->lock);
        prev = curr;
    }
    if(strcmp(prev->key,data) == 0){
        //shoudlnt happen but if the first node is the data
        pthread_mutex_unlock(&prev->lock);
        return(prev->value);
    }
    pthread_mutex_unlock(&prev->lock);
    return(NULL);
}