Project 3

Name of file is Server.c
We also have a header file called Server.h

CREATED BY:
-Colton Carls - (cwc74) <-NetID
-Jonathan.Martinez - (jem483) <-NetID

DUE DATE: May 3rd

PROGRAM NAME:
Network Communication (Server)

PROGRAM DESCRIPTION: 
A program that uses sockets and multithreading to communicate three different requests that a client program sends to a 
server. The server has a key/value pair and these commands are used to set, get or delete these key/value pairs.


IMPORTANT NOTES ABOUT THE PROGRAM:
*******WE INCLUDED A MAKEFILE IN THE TAR***********

Quick Notes:
-ALL COMMANDS MUST BE CAPITALIZED (GET, SET, DEL)
-Our program does not accept keys of length 0
-Insert will overwrite when SET is called on a key that is already present in the linkedlist, it will than continue and overwrite the value as well. However, this will not cause a duplicate in the linkedlist.

Our communication protocol has three requests that the client may send to the serve
  1. GET -> Requests the current Value that the Key is holding.
  2. SET-> Will Set a key/value pair on the server
  3. DEL-> Will delete the key value pairs

 This methods if not handled correctly do come with consequences:
    Program will close the connection to the client if:
    -There is a malformed code, for example you type gert instead of GET, the program will exit but the server will continue to run
    -If the length does not add up, if you request a value of a key and provide the wrong length of the key, the program will exit
        -In general, if the length is to long or to short the program will terminate the client connection.
    -If there is errors with mallocing or anything to do with the servers fault, the connection will close

    The program will continue to run if:
    -You try to look up a key and the key is not present in the linkedlist

We shall take advantage of the fact that thanks to multithreading, we can allow the server program to run as a passive listener. 
It will allow for multiple connections, and portability accross different computers (C code). 
The 400+ codelines is broken among two files, server.c and server.h. It is mostly based on the echoes /echoes2 program under resources -- cs214 Spring Menendez.
The C code provided, binds the user designated port (as opposed to a default, set MACROS) and keeps track of the values using a Linklist node struct for key(s) values.
Designated MACROS for backlog (running connections) value is 5. _POSIX_C_SOURCE 200809L. #define BUFSIZE 8.

For each client request, the server has a corresponding response messageindicating success. Each response begins with a response code followed by a newline.

*********We include a printlist function to easily tell what is in the linkedlist, (we commented this code out but you can uncomment it to check the linkedlist)************

We also used code from one of the homework assigments (String Buffer). We found this to be very useful when reading char by char because we could easily munipulate the String
by using the append method we had already written. This saved us alot of time. 


TESTING STRATEGY:
To test our code we mainly used the command nc <host_name> <port_number>.
We decided to use netcat because it was a faster alternative than making and actual client side program to test with.
It also was easier to test multiple connections.
Stress test under ilab machines.