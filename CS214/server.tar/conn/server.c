#include "server.h"
#define BACKLOG 5
#define BUFSIZE 8
/*
Created By: Colton Carls and Jonathan Martinez
Program name: Network Communication (SERVER)
Date: 5/3/2021

NOTES:
-ALL COMMANDS MUST BE CAPITALIZED (GET, SET, DEL)
-Our program does not accept keys of length 0
*/
//head of the linked list

int running = 1;

int server(char *port);
void *echo(void *arg);
int main (int argc, char *argv[]) {
//server only takes one arg-> port #
if (argc != 2) {
    //we were not given enough args to continue
		printf("Not enough args: EXITING\n");
		exit(EXIT_FAILURE);
	}
    //port number given
    (void) server(argv[1]);
    return EXIT_SUCCESS;
}

int server(char *portNum){
    int code = init_NodeHead();
    if(code == -1){
        //print to server side, there was a problem with linkedlist resetting after each new connection
        printf("ERR\nSRV\n");
    }
    struct addrinfo hints, *info_list, *info;
    struct connection *con;
    int error, sfd;
    pthread_t tid;

    memset(&hints,0,sizeof(struct addrinfo));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    error = getaddrinfo(NULL, portNum, &hints, &info_list);
 
    //listening to client
    for (info = info_list; info != NULL; info = info->ai_next) {
        sfd = socket(info->ai_family, info->ai_socktype, info->ai_protocol);
        if (sfd == -1) {
            continue;
        }
        if ((bind(sfd, info->ai_addr, info->ai_addrlen) == 0) &&
            (listen(sfd, BACKLOG) == 0)) {
            break;
        }
        close(sfd);
    }

    freeaddrinfo(info_list);

    while (running) {
		con = malloc(sizeof(struct connection));
        con->addr_len = sizeof(struct sockaddr_storage);
        con->fd = accept(sfd, (struct sockaddr *) &con->addr, &con->addr_len);
        //accepting connections
        if (con->fd == -1) {
            perror("accept");
            continue;
        }
        error = pthread_create(&tid, NULL, echo, con);

        if (error != 0) {
            fprintf(stderr, "Unable to create thread: %d\n", error);
            close(con->fd);
            free(con);
            continue;
        }

        pthread_detach(tid);

    }

    return 0;
}

void *echo(void *arg){
    printf("SERVER SCRIPT STATUS: NEW CLIENT JOINED\n");
    char host[100], port[10];
    struct connection *c = (struct connection *) arg;
    int error;
    

    error = getnameinfo((struct sockaddr *) &c->addr, c->addr_len, host, 100, port, 10, NI_NUMERICSERV);

    if (error != 0) {
        fprintf(stderr, "getnameinfo: %s", gai_strerror(error));
        close(c->fd);
        return NULL;
    }

    int sock2 = dup(c->fd);
    FILE *fin = fdopen(c->fd, "r");
    //read socket
    FILE *fout = fdopen(sock2, "w");
    //write socket
    char ch;
    //we know a command can only be 3 chars long SET GET OR DEL
     //init the head of the linked list. The head is a reference to the list and never holds any real data

    strbuf_t stringBuilder;
    sb_init(&stringBuilder,4);
    while((ch = getc(fin))){
        if(ch == '\n'){
            if(strcmp(stringBuilder.data,"GET")==0){
                //grabbing int
                char num;
                    int length;
                    strbuf_t stringBuilder1;
                    sb_init(&stringBuilder1,1);
                    //problem reading number and next input with fscanf
                    while((num = getc(fin))){
                        if(num == '\n'){
                            break;
                        }
                        else{
                        sb_append(&stringBuilder1,num);
                        }
                    }
                    length = atoi(stringBuilder1.data);
                    if(length == 0){
                    //key cant be 0
                    fprintf(fout,"ERR\nBAD\n");
                    fflush(fout);
                    break;
                }
                else{
                    //grab the Key
                     strbuf_t stringBuilder2;
                     sb_init(&stringBuilder2,5);
                    char ap;
                    while((ap = getc(fin))){
                        //build key arg
                        if(ap == '\n'){
                            break;
                        }
                        else{
                        sb_append(&stringBuilder2,ap);
                        }
                    }
                        char *getRet = get(stringBuilder2.data,length,fout);
                        if(getRet == NULL){
                            //KNF
                             if(strlen(stringBuilder2.data)+1 != length){
                                fprintf(fout,"ERR\nLEN\n");
                                fflush(fout);
                                break;
                            }
                            else{
                            fprintf(fout,"KNF\n");
                            fflush(fout);
                            }
                        }
                        else{
                        int vallength = strlen(getRet);
                        fprintf(fout,"OKG\n%d\n%s\n",vallength+1,getRet);
                        fflush(fout);
                        //printlist();
                        }
                }
                }
            else if(strcmp(stringBuilder.data,"SET")==0){
                    char num;
                    int length;
                    strbuf_t stringBuilder1;
                    sb_init(&stringBuilder1,1);
                    //problem reading number and next input with fscanf
                    //FIX ******put a check for atoi
                    while((num = getc(fin))){
                        if(num == '\n'){
                            break;
                        }
                        else{
                        sb_append(&stringBuilder1,num);
                        }
                    }
                    length = atoi(stringBuilder1.data);
                    if(length == 0){
                    //key cant be 0
                    fprintf(fout,"ERR\nBAD\n");
                    fflush(fout);
                    break;
                }
                else{
                    strbuf_t stringBuilder2;
                    strbuf_t stringBuilder3;
                    sb_init(&stringBuilder2,5);
                    sb_init(&stringBuilder3,5);
                    char ap;
                    char pa;
                    int x=0;
                    //grab key
                    while((ap = getc(fin))){
                        //build key arg
                        if(ap == '\n'){
                            break;
                        }
                        else{
                        x++;
                        sb_append(&stringBuilder2,ap);
                        }
                    }
                    while((pa = getc(fin))){
                        //build value arg
                        if(pa == '\n'){
                            break;
                        }
                        else{
                        x++;
                        sb_append(&stringBuilder3,pa);
                        }
                    }
                    //grab value
                    //x will keep track of length
                    int statuscode;
                    statuscode = insert(stringBuilder2.data,stringBuilder3.data,length);
                    if(statuscode == -1){
                        fprintf(fout,"ERR\nLEN\n");
                        fflush(fout);
                        //close(c->fd);
                        break;
                    }
                    else{
                        fprintf(fout,"OKS\n");
                        fflush(fout);
                    }
                   // printlist();
                }
            }
            else if(strcmp(stringBuilder.data,"DEL")==0){
                //GRAB THE NUMBER
                char num;
                int length;
                strbuf_t stringBuilder1;
                sb_init(&stringBuilder1,1);
                while((num = getc(fin))){
                    if(num == '\n'){
                        break;
                    }
                    else{
                        sb_append(&stringBuilder1,num);
                    }
                }
                length = atoi(stringBuilder1.data);
                if(length == 0){
                    //key cant be 0
                    fprintf(fout,"ERR\nBAD\n");
                    fflush(fout);
                    break;
                }
                else{
                //GRAB THE KEY
                strbuf_t stringBuilder2;
                sb_init(&stringBuilder2,5);
                char ap;
                while((ap = getc(fin))){
                        //build key arg
                        if(ap == '\n'){
                            break;
                        }
                        else{
                        sb_append(&stringBuilder2,ap);
                        }
                    }
                char *delRet = delete(stringBuilder2.data,length,fout);
                if(delRet == NULL){
                    fprintf(fout,"KNF\n");
                    fflush(fout);
                }
                else{
                int vallength = strlen(delRet);
                fprintf(fout,"OKD\n%d\n%s\n",vallength+1,delRet);
                fflush(fout);
                //printlist();
                }
                }
            }
            else{
                //unknown message code
                fprintf(fout,"ERR\nBAD\n");
                fflush(fout);
                break;
            }
            memset(stringBuilder.data,'\0',stringBuilder.used-1); 
            stringBuilder.used = 1;
            
        }
        else{
            sb_append(&stringBuilder,ch);
        }
    }
    fclose(fin);
    fclose(fout);
    close(c->fd);
    free(c);
    return NULL;
}

